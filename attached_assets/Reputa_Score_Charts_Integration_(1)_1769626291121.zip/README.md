
  # Reputa Score Charts Integration

  This is a code bundle for Reputa Score Charts Integration. The original project is available at https://www.figma.com/design/bB1RUmf6zq1JlmQgJmW22x/Reputa-Score-Charts-Integration.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  