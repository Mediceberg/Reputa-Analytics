# Reputa Score - Blockchain Reputation System

نظام شامل لتحليل وتقييم السمعة على البلوكشين لشبكة Pi Network Testnet مع واجهة مستخدم احترافية وتصميم أصلي.

## المميزات الرئيسية

- 🌐 **دعم متعدد اللغات** (العربية RTL، الفرنسية، الصينية، الإنجليزية)
- 📊 **رسوم بيانية تفاعلية** بأربعة أنواع مختلفة
- 🔐 **تكامل Pi Network SDK** للمصادقة والمدفوعات
- 🎮 **وضع التجربة (Demo Mode)** ببيانات واقعية
- 🧪 **وضع Testnet** للاتصال الحقيقي بشبكة Pi
- 📈 **بروتوكول السمعة** مع عوامل تقييم متعددة
- 💰 **تتبع محفظة Pi DEX** للتوكنات والمعاملات
- ⚡ **بنية نظيفة** مع فصل صارم بين الطبقات
- 🎨 **تصميم أصلي** مستوحى من Figma مع تأثيرات بصرية احترافية

## هيكل المشروع

```
/
├── api/                      # Serverless API routes (Vercel)
│   ├── auth.ts              # Pi Network authentication
│   ├── approve.ts           # Payment approval
│   ├── complete.ts          # Payment completion
│   ├── get-wallet.ts        # Wallet data fetching
│   └── pi-dex.ts            # Pi DEX data
├── components/              # React components
│   ├── charts/             # Chart components
│   │   ├── TransactionTimeline.tsx
│   │   ├── PointsBreakdown.tsx
│   │   ├── RiskActivity.tsx
│   │   └── TokenPortfolio.tsx
│   ├── Header.tsx
│   ├── Sidebar.tsx
│   ├── LanguageSelector.tsx
│   ├── TrustScoreCard.tsx
│   ├── WalletBalance.tsx
│   ├── ProgressCard.tsx
│   ├── ProductsReport.tsx
│   ├── ScoreBreakdown.tsx
│   ├── Recommendations.tsx
│   └── PiDexSection.tsx
├── hooks/                   # Custom React hooks
│   └── useLanguage.ts
├── locales/                 # Translation files
│   └── translations.ts
├── services/                # Business logic & integrations
│   ├── piSdk.ts            # Pi SDK wrapper
│   ├── reputationProtocol.ts
│   ├── mockData.ts
│   └── chartDataProcessor.ts
├── types/                   # TypeScript type definitions
│   └── index.ts
└── App.tsx                  # Main application component
```

## مكونات الواجهة

### القسم الرئيسي
- **Header**: رأس الصفحة مع معلومات المستخدم واختيار اللغة
- **Sidebar**: القائمة الجانبية مع التنقل وزر تبديل الأوضاع

### البطاقات الرئيسية
- **WalletBalance**: عرض رصيد المحفظة ومعلومات الحساب
- **TrustScoreCard**: عداد دائري لنقاط السمعة مع المستوى
- **ProgressCard**: دوائر تقدم متعددة مع أشرطة التقدم
- **ScoreBreakdown**: تفصيل نقاط السمعة حسب العوامل

### الرسوم البيانية
- **TransactionTimeline**: خط زمني للمعاملات اليومية/الأسبوعية/الشهرية
- **PointsBreakdown**: مخطط دائري لتوزيع النقاط
- **RiskActivity**: مخطط نقطي للمخاطر مقابل النشاط
- **TokenPortfolio**: مخطط أعمدة لمحفظة التوكنات

### أقسام إضافية
- **ProductsReport**: تقرير المنتجات بتصميم احترافي
- **PiDexSection**: قسم Pi DEX للتوكنات
- **Recommendations**: توصيات لتحسين السمعة

## التثبيت

1. استنسخ المستودع:
```bash
git clone https://github.com/your-username/reputa-score.git
cd reputa-score
```

2. تثبيت الاعتماديات:
```bash
npm install
```

3. إنشاء ملف البيئة:
```bash
cp .env.example .env
```

4. تكوين بيانات Pi Network في `.env`:
```env
VITE_PI_ENV=testnet
VITE_APP_ID=your_pi_app_id
PI_API_KEY=your_pi_api_key
PI_WALLET_SECRET=your_pi_wallet_secret
```

## التطوير

تشغيل خادم التطوير:
```bash
npm run dev
```

## النشر

### Vercel

1. قم بإرسال الكود إلى GitHub

2. استيراد المشروع في Vercel

3. تكوين متغيرات البيئة في لوحة تحكم Vercel:
   - `VITE_PI_ENV`
   - `VITE_APP_ID`
   - `PI_API_KEY` (Server-side only)
   - `PI_WALLET_SECRET` (Server-side only)

4. نشر!

## بروتوكول السمعة

يتم حساب درجة السمعة بناءً على:

- **عمر الحساب** (20%): مدى استمرار وجود المحفظة
- **عدد المعاملات** (15%): عدد المعاملات التي تم تنفيذها
- **قيمة المعاملات** (15%): القيمة الإجمالية للمعاملات
- **مكافأة التثبيت** (15%): كمية Pi المثبته
- **مكافأة أيام التعدين** (20%): عدد أيام التعدين لـ Pi
- **نقاط النشاط** (15%): مستوى النشاط الحديث

**عقوبات**:
- المعاملات غير المرغوب فيها تقلل من الدرجة الإجمالية

## الرسوم البيانية

### 1. خط الزمن للمعاملات
يظهر أنماط المعاملات اليومية/ الأسبوعية/ الشهرية، مع تمييز بين:
- المعاملات الداخلية (نقاط إيجابية)
- المعاملات الخارجية (نقاط سلبية)

### 2. تحليل النقاط
رسم دائري يظهر توزيع درجة السمعة عبر عوامل مختلفة.

### 3. المخاطر مقابل النشاط
رسم تشتت يربط مستوى النشاط بتقييم المخاطر.

### 4. محفظة التوكنات
رسم شريط يعرض توازن Pi DEX وقيمها.

## دعم متعدد اللغات

اللغات المدعومة:
- الإنجليزية (en)
- العربية (ar) - دعم RTL
- الفرنسية (fr)
- الصينية (zh)

تتم حفظ تفضيل اللغة في localStorage وتستمر عبر الجلسات.

## وضع التجربة مقابل وضع Testnet

### وضع التجربة
- يستخدم بيانات واقعية
- لا يتطلب اتصالًا بشبكة Pi
- مثالي للاختبار والتطوير

### وضع Testnet
- يتصل بالشبكة الفعلية لـ Pi Network Testnet
- يتطلب Pi Browser أو Pi SDK
- يستخدم بيانات المحفظة الفعلية

## التقنيات المستخدمة

- **واجهة المستخدم الأمامية**: React، TypeScript، Tailwind CSS
- **الرسوم البيانية**: Recharts
- **الأيقونات**: Lucide React
- **الواجهة الخلفية**: Vercel Serverless Functions
- **البلوكشين**: Pi Network SDK

## الأمان

⚠️ **ملاحظات الأمان المهمة**:
- لا تقم بتضمين ملف `.env` في التحكم في الإصدارات
- حافظ على `PI_API_KEY` و `PI_WALLET_SECRET` على الجانب الخلفي فقط
- هذا التطبيق للمضامنة فقط
- ليس مصممًا لجمع بيانات هوية شخصية أو حماية البيانات الحساسة

## الترخيص

ترخيص MIT - استخدمه في مشروعاتك الخاصة!

## الدعم

للاستفسارات والمشاكل، يرجى فتح قضية على GitHub.

## المساهمة

المساهمات مرحبًا بها! يرجى تقديم طلب سحب (Pull Request) إذا كنت ترغب في مساهمة.