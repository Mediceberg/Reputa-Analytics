# 🌟 Reputa Score v2.5 - محلل سمعة محافظ Pi Network

**منصة تحليل احترافية لسمعة المحافظ على شبكة Pi Network باستخدام الذكاء الاصطناعي**

---

## 🎯 نظرة عامة

Reputa Score هو تطبيق ويب احترافي لتحليل سمعة محافظ Pi Network باستخدام:
- 🔍 **تحليل سلوك المحفظة** - فهم أنماط التعاملات
- 📊 **نقاط السمعة (0-1000)** - Reputa Score الشامل
- 🛡️ **تقييم المخاطر** - تحليل ذكي للثقة والأمان
- 🎨 **تقارير احترافية** - رؤى متقدمة للمستخدمين المحترفين

---

## ✨ المميزات الرئيسية

### للجميع (Explorer View)
- ✅ فحص عناوين محافظ Pi Network (تبدأ بحرف G)
- ✅ عرض نقاط السمعة الأساسية (Reputa Score)
- ✅ آخر 10 عمليات حقيقية (استبعاد العمليات الصفرية)
- ✅ معلومات عامة عن المحفظة

### للمحترفين (Advanced Insights)
- 🔐 **تحليل سلوكي بالذكاء الاصطناعي** - رؤى عميقة
- 🔐 **4 مقاييس متقدمة** - Consistency، Network Trust، Predictability، Stability
- 🔐 **خريطة المخاطر** - تحليل مفصل للمخاطر
- 🔐 **تقارير تدقيق كاملة** - PDF-ready reports

---

## 🚀 البدء السريع

### المتطلبات
- Node.js 18+ 
- npm أو yarn أو pnpm
- Git (للنشر)

### التثبيت

```bash
# 1. استنساخ المشروع أو تحميله
git clone https://github.com/your-username/reputa-score.git
cd reputa-score

# 2. تثبيت الحزم
npm install

# 3. تشغيل بيئة التطوير
npm run dev

# 4. افتح المتصفح
# http://localhost:3000
```

### البناء للإنتاج

```bash
# بناء المشروع
npm run build

# معاينة النسخة المبنية
npm run preview
```

---

## 📁 هيكل المشروع

```
reputa-score/
├── src/
│   ├── assets/              # الصور والأصول
│   │   └── logo.svg         # شعار التطبيق
│   ├── app/
│   │   ├── App.tsx          # المكون الرئيسي
│   │   └── components/      # مكونات React
│   └── styles/              # ملفات الأنماط
├── public/                  # الملفات الثابتة
├── package.json             # الحزم والسكربتات
├── vite.config.ts           # إعدادات Vite
├── vercel.json              # إعدادات Vercel
└── README.md                # هذا الملف
```

---

## 🎨 تخصيص الشعار

### استبدال الشعار

```bash
# ضع شعارك في:
src/assets/logo.svg   # أو logo.png

# الصيغ المدعومة
- SVG (موصى به)
- PNG
- JPG
```

### إذا غيرت اسم الملف

حدّث الـ imports في:
- `src/app/App.tsx`
- `src/app/components/WalletChecker.tsx`
- `src/app/components/AuditReport.tsx`

```typescript
// مثال
import logoImage from '../assets/my-logo.svg';
```

---

## 🌐 النشر على Vercel

### الخطوة 1: رفع الكود على GitHub

```bash
# إنشاء repository على GitHub
# https://github.com/new

# ثم في مجلد المشروع:
git init
git add .
git commit -m "Initial commit - Reputa Score v2.5"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPO.git
git push -u origin main
```

### الخطوة 2: ربط Vercel

#### الطريقة السهلة (Dashboard)

1. اذهب إلى: https://vercel.com
2. سجل دخول بحساب GitHub
3. اضغط "New Project"
4. اختر repository الخاص بك
5. اضغط "Deploy"

**الإعدادات التلقائية**:
- Framework: Vite ✅
- Build Command: `npm run build` ✅
- Output Directory: `dist` ✅

#### الطريقة السريعة (CLI)

```bash
# تثبيت Vercel CLI
npm install -g vercel

# تسجيل الدخول
vercel login

# النشر
vercel --prod
```

### الخطوة 3: النشر التلقائي

بعد الربط الأول، أي تحديث يُنشر تلقائياً:

```bash
git add .
git commit -m "تحديث الميزة X"
git push
# ✨ Vercel سيبني وينشر تلقائياً!
```

---

## 🔧 حل المشاكل الشائعة

### الشعار لا يظهر بعد النشر

**السبب**: مسار خاطئ

**الحل**:
```typescript
// ❌ خطأ
import logo from 'figma:asset/...'
import logo from '/assets/logo.svg'

// ✅ صحيح
import logo from '../assets/logo.svg'
```

### 404 عند تحديث الصفحة

**السبب**: Vercel لا يعرف التطبيق كـ SPA

**الحل**: ملف `vercel.json` موجود ويحل المشكلة ✅

### البناء فشل على Vercel

```bash
# 1. تحقق محلياً أولاً
npm run build

# 2. إذا فشل، نظّف وأعد التثبيت
rm -rf node_modules dist
npm install
npm run build

# 3. إذا نجح، ارفع التحديثات
git add .
git commit -m "Fix build"
git push
```

---

## 🎯 نظام النقاط (Reputa Score)

### المعايير (0-1000 نقطة)

| المعيار | الوزن | الوصف |
|---------|-------|--------|
| **Balance Weight** | 30% | وزن الرصيد في المحفظة |
| **Account Age** | 40% | عمر الحساب ونضجه |
| **Activity Level** | 30% | مستوى النشاط والتعاملات |

### مستويات الثقة

- 🟢 **Elite** (900-1000): سمعة استثنائية
- 🔵 **High** (700-899): سمعة قوية وموثوقة
- 🟡 **Medium** (500-699): سمعة متوسطة
- 🔴 **Low** (0-499): سمعة محدودة

### مقاييس متقدمة (Pro فقط)

1. **Consistency Score** - درجة الاستمرارية (0-100%)
2. **Network Trust** - ثقة الشبكة (0-100%)
3. **Predictability** - القابلية للتنبؤ (0-100%)
4. **Stability Index** - مؤشر الاستقرار (0-100%)

---

## 🔐 نظام الصلاحيات

### Explorer View (مجاني)
- عرض نقاط السمعة الأساسية
- آخر 10 معاملات
- معلومات عامة

### Advanced Insights (1 Pi)
- تحليل سلوكي بالذكاء الاصطناعي
- 4 مقاييس متقدمة
- خريطة المخاطر
- تقارير تدقيق كاملة

**ملاحظة**: النظام الحالي يستخدم بيانات تجريبية. لتفعيل الدفع الحقيقي، يجب دمج Pi SDK.

---

## 🛡️ الخصوصية والأمان

### ما نستخدمه
- ✅ بيانات البلوكشين العامة فقط
- ✅ لا نطلب كلمات المرور أبداً
- ✅ لا نخزن مفاتيح خاصة
- ✅ لا نجمع معلومات شخصية

### البيانات المستخدمة
- عنوان المحفظة (عام)
- رصيد المحفظة (عام)
- سجل المعاملات (عام)

**كل البيانات متاحة للجميع على البلوكشين**

---

## 📊 التقنيات المستخدمة

### Frontend
- **React** 18+ - مكتبة واجهة المستخدم
- **TypeScript** - الأمان والتايبات
- **Tailwind CSS** 4.0 - التصميم السريع
- **Motion** - الحركات والأنيميشن

### Build & Deploy
- **Vite** 6+ - أداة البناء السريعة
- **Vercel** - الاستضافة والنشر
- **GitHub** - التحكم بالإصدارات

### UI Components
- **Shadcn UI** - مكونات UI جاهزة
- **Radix UI** - مكونات headless
- **Lucide Icons** - الأيقونات

---

## 📱 التوافق

### المتصفحات
- ✅ Chrome/Edge 90+
- ✅ Firefox 88+
- ✅ Safari 14+
- ✅ Pi Browser (موصى به)

### الأجهزة
- ✅ Desktop (محسّن)
- ✅ Tablet (responsive)
- ✅ Mobile (responsive)

---

## 🚀 الأداء

### أهداف السرعة
- First Load: < 2 ثانية
- Interactive: < 3 ثواني
- Subsequent Loads: < 500ms (cached)

### حجم الملفات
- Main bundle: ~250 KB
- Compressed (gzip): ~80 KB
- Logo SVG: ~2 KB

---

## 📚 الوثائق الكاملة

### باللغة الإنجليزية
- 📖 [README.md](./README.md) - الوثائق الكاملة
- 🚀 [QUICKSTART.md](./QUICKSTART.md) - دليل البدء السريع
- 🏗️ [PROJECT_STRUCTURE.md](./PROJECT_STRUCTURE.md) - هيكل المشروع
- 👨‍💻 [DEVELOPER_NOTES.md](./DEVELOPER_NOTES.md) - ملاحظات المطورين
- 📋 [CHANGES_SUMMARY.md](./CHANGES_SUMMARY.md) - ملخص التغييرات

### باللغة العربية
- 🚀 [DEPLOYMENT_GUIDE.md](./DEPLOYMENT_GUIDE.md) - دليل النشر الكامل
- 📄 [README_AR.md](./README_AR.md) - هذا الملف

---

## 🎓 موارد التعلم

### React
- [React Docs](https://react.dev/)
- [React Tutorial Arabic](https://ar.reactjs.org/tutorial/tutorial.html)

### Vite
- [Vite Guide](https://vitejs.dev/guide/)
- [Vite in 100 Seconds](https://www.youtube.com/watch?v=KCrXgy8qtjM)

### Tailwind CSS
- [Tailwind Docs](https://tailwindcss.com/docs)
- [Tailwind Arabic Resources](https://tailwindcss.com/)

---

## 🔄 خارطة الطريق

### قريباً
- [ ] دمج Pi SDK الحقيقي
- [ ] جلب بيانات البلوكشين الفعلية
- [ ] تصدير التقارير بصيغة PDF
- [ ] المزيد من مقاييس المحافظ

### مستقبلاً
- [ ] دعم اللغة العربية الكامل
- [ ] الوضع الليلي (Dark Mode)
- [ ] رسوم بيانية للاتجاهات
- [ ] مقارنة المحافظ
- [ ] حسابات المستخدمين
- [ ] تطبيق موبايل

---

## 🤝 المساهمة

نرحب بالمساهمات! إذا كان لديك اقتراحات:

1. Fork المشروع
2. أنشئ branch جديد (`git checkout -b feature/amazing`)
3. Commit التغييرات (`git commit -m 'إضافة ميزة رائعة'`)
4. Push للـ branch (`git push origin feature/amazing`)
5. افتح Pull Request

---

## 📞 الدعم

### لديك سؤال؟
- 📧 Email: support@reputa-analytics.com
- 🐛 Issues: [GitHub Issues](https://github.com/your-repo/issues)
- 📚 Docs: [DEPLOYMENT_GUIDE.md](./DEPLOYMENT_GUIDE.md)

### مشاكل تقنية؟
1. تحقق من [DEPLOYMENT_GUIDE.md](./DEPLOYMENT_GUIDE.md)
2. تحقق من [DEVELOPER_NOTES.md](./DEVELOPER_NOTES.md)
3. ابحث في GitHub Issues
4. افتح issue جديد

---

## 📄 الترخيص

© 2024 Reputa Analytics. جميع الحقوق محفوظة.

**مبني بـ ❤️ لمجتمع Pi Network**

---

## ✅ قائمة التحقق قبل النشر

- [ ] الشعار موجود في `/src/assets/logo.svg`
- [ ] `npm install` يعمل بدون أخطاء
- [ ] `npm run build` ينجح
- [ ] `npm run preview` يُظهر التطبيق بشكل صحيح
- [ ] لا توجد أخطاء في console المتصفح
- [ ] جميع المميزات تعمل
- [ ] التصميم responsive على الموبايل
- [ ] يعمل على Pi Browser

---

## 🎉 شكراً لاستخدام Reputa Score!

**النسخة**: 2.5.0
**آخر تحديث**: 2024
**الحالة**: ✅ جاهز للإنتاج

**🚀 ابدأ الآن واكتشف سمعة محفظتك على Pi Network!**
